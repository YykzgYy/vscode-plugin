"use strict";
import {
  SignatureHelp,
  SignatureInformation,
  ParameterInformation
} from 'vscode';

import Logger from "kite-connector/lib/logger";
import { parseJSON, stripTags, getFunctionDetails } from "./utils";
import { signaturePath, normalizeDriveLetter } from "./urls";
import { valueLabel, parameterType } from "./data-utils";

export default class KiteSignatureProvider {
  constructor(Kite, isTest) {
    this.Kite = Kite;
    this.isTest = isTest;
  }

  provideSignatureHelp(document, position) {
    const text = document.getText();

    if (text.length > this.Kite.maxFileSize) {
      Logger.warn("buffer contents too large, not attempting signature");
      return null;
    }

    const cursorPosition = document.offsetAt(position);
    const payload = {
      text,
      editor: "vscode",
      filename: normalizeDriveLetter(document.fileName),
      cursor_runes: cursorPosition,
      offset_encoding: "utf-16"
    };
    Logger.debug(payload);

    return this.Kite.request(
      {
        path: signaturePath(),
        method: "POST"
      },
      JSON.stringify(payload),
      document
    )
      .then(data => {
        data = parseJSON(data, {});

        const [call] = data.calls;

        const { callee } = call;

        const help = new SignatureHelp();
        help.activeParameter = call.arg_index;
        help.activeSignature = 0;

        const label = "⟠ " + stripTags(valueLabel(callee));
        const sig = new SignatureInformation(label);
        const detail = getFunctionDetails(callee);
        sig.parameters = (detail.parameters || []).map(p => {
          const label = p.inferred_value
            ? `${p.name}:${stripTags(parameterType(p))}`
            : p.name;
          const param = new ParameterInformation(label);
          return param;
        });

        if (
          Array.isArray(detail.return_value) &&
          detail.return_value.length &&
          detail.return_value[0].type
        ) {
          sig.documentation = `Returns → ${detail.return_value[0].type}`;
        }

        help.signatures = [sig];

        return help;
      })
      .catch(() => null);
  }
}
