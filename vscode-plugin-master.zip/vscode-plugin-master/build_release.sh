#!/bin/bash

make build-production