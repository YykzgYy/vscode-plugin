import os

def foo():
    return 'bar'

foo()
