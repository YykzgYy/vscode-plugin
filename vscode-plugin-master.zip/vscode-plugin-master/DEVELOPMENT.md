# Kite plugin for VSCode

To use this plugin you must [download and install the Kite Engine](https://kite.com).

### Installation

Download Kite from http://kite.com/. During the installation process, select
"Visual Studio Code" in the list of editors and Kite will install this plugin
for you.

### Debugging pointers

Open Visual Studio Code, navigate to this project directory, and change the
launch target from `Launch Extension` to `Launch Tests`. Then, hit the green
play triangle. Testing from the command line to come as soon as I can figure
it out.
